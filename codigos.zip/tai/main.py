import smtplib
import pandas as pd
import hashlib
import psycopg2
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Configurações do Gmail
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
EMAIL_REMETENTE = "academicosservicos55@gmail.com"
SENHA = "hbxpdufkglxfdbel"

# Configuração do Banco de Dados no Render
DB_URL = "postgresql://cliques_dwqh_user:F1gSTRIHqZus712E6Vd91hlprQXagIdn@dpg-d0r405qdbo4c73a0ok9g-a.oregon-postgres.render.com/cliques_dwqh"

def conectar_db():
    """Cria uma conexão segura com o banco de dados no Render"""
    try:
        conn = psycopg2.connect(DB_URL, sslmode="require")
        return conn
    except Exception as e:
        print(f"Erro na conexão com o banco: {e}")
        return None

# Criar um hash baseado no e-mail
def gerar_hash(email):
    hash_obj = hashlib.sha256(email.encode("utf-8"))
    return hash_obj.hexdigest()

def salvar_hash_no_banco(email, hash_email):
    """Insere o hash e o e-mail no banco de dados"""
    conn = conectar_db()
    if not conn:
        print("Erro: Não foi possível conectar ao banco.")
        return
    
    try:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO cliques_email (email, hash)
            VALUES (%s, %s)
            ON CONFLICT (hash) DO NOTHING;
        """, (email, hash_email))
        
        conn.commit()
        cur.close()
        conn.close()
        print(f"Hash salvo no banco: {hash_email}")

    except Exception as e:
        print(f"Erro ao salvar no banco: {e}")

# Criar e enviar os e-mails
def enviar_email(destinatario, assunto, mensagem_base):
    try:
        hash_email = gerar_hash(destinatario)

        # Criar link personalizado com o hash
        link_personalizado = f"https://leticiavicenteteodoro.github.io/Curso/?key={hash_email}"

        # Personaliza a mensagem adicionando o link único
        mensagem = f"""{mensagem_base}

<a href="{link_personalizado}" target="_blank">{link_personalizado}</a>

<p>Atenciosamente, Leticia 
</p>"""

        msg = MIMEMultipart()
        msg["From"] = EMAIL_REMETENTE
        msg["To"] = destinatario
        msg["Subject"] = assunto
        msg.attach(MIMEText(mensagem, "html"))

        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(EMAIL_REMETENTE, SENHA)
            server.sendmail(EMAIL_REMETENTE, destinatario, msg.as_string())

        print(f"E-mail enviado para {destinatario} - Hash: {hash_email}")

        # Salva no banco após o envio
        salvar_hash_no_banco(destinatario, hash_email)

        return destinatario, hash_email, link_personalizado

    except Exception as e:
        print(f"Erro ao enviar para {destinatario}: {e}")
        return destinatario, None, None

# Carregar lista de e-mails de um arquivo CSV
df = pd.read_csv("lista_emails.csv")  # O arquivo deve conter uma coluna "email"

# Assunto e mensagem base
assunto = "Avalie Nosso Projeto de Extensão"
mensagem_base = """<p>Olá,</p>

<p>Sou aluna do 5º período do curso de Ciências da Computação. Eu e meu grupo estamos desenvolvendo um projeto para uma disciplina extensionista.</p>
<p>Gostaríamos muito que você olhasse como está ficando o projeto e se possível, dar um feedback. Assim, poderemos melhorar cada vez mais! </p>

"""


# Loop para enviar e-mails para todos os destinatários
for email in df["email"]:
    enviar_email(email, assunto, mensagem_base)

print("Todos os e-mails foram enviados com sucesso!")
